<?php
/**
 * 四季特效插件 - 春/夏/秋/冬粒子效果
 *
 * @package FourSeasons
 * @author Lin.
 * @version 1.0.0
 * @link https://linyu.live/
 */
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class FourSeasons_Plugin implements Typecho_Plugin_Interface
{
    private const VERSION = '1.0.0';

    /**
     * 激活插件
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->footer = [__CLASS__, 'render'];
        return _t('四季特效插件已激活，请在"插件 → FourSeasons"中配置季节开关。');
    }

    /**
     * 禁用插件
     */
    public static function deactivate()
    {
    }

    /**
     * 插件配置面板
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        // 简约模式开关
        $simpleMode = new Typecho_Widget_Helper_Form_Element_Radio(
            'simpleMode',
            ['1' => _t('开启'), '0' => _t('关闭')],
            '0',
            _t('🎨 简约模式'),
            _t('开启后所有季节将使用圆点代替复杂形状，性能更好更简洁')
        );
        $form->addInput($simpleMode);

        // 春 - 樱花
        $spring = new Typecho_Widget_Helper_Form_Element_Radio(
            'spring',
            ['1' => _t('开启'), '0' => _t('关闭')],
            '0',
            _t('🌸 春季 - 樱花飘落'),
            _t('单瓣樱花从顶部飘落，轻盈旋转')
        );
        $form->addInput($spring);

        $springDensity = new Typecho_Widget_Helper_Form_Element_Text(
            'springDensity',
            null,
            '40',
            _t('樱花数量'),
            _t('建议范围 20-80')
        );
        $springDensity->input->setAttribute('type', 'number');
        $springDensity->input->setAttribute('min', '10');
        $springDensity->input->setAttribute('max', '150');
        $form->addInput($springDensity);

        // 夏 - 细雨
        $summer = new Typecho_Widget_Helper_Form_Element_Radio(
            'summer',
            ['1' => _t('开启'), '0' => _t('关闭')],
            '0',
            _t('🌧️ 夏季 - 细雨飘洒'),
            _t('斜向飘落的雨丝')
        );
        $form->addInput($summer);

        $summerDensity = new Typecho_Widget_Helper_Form_Element_Text(
            'summerDensity',
            null,
            '60',
            _t('雨丝数量'),
            _t('建议范围 30-100')
        );
        $summerDensity->input->setAttribute('type', 'number');
        $summerDensity->input->setAttribute('min', '20');
        $summerDensity->input->setAttribute('max', '200');
        $form->addInput($summerDensity);

        // 秋 - 落叶
        $autumn = new Typecho_Widget_Helper_Form_Element_Radio(
            'autumn',
            ['1' => _t('开启'), '0' => _t('关闭')],
            '0',
            _t('🍂 秋季 - 落叶飘零'),
            _t('枫叶形状从顶部旋转飘落')
        );
        $form->addInput($autumn);

        $autumnDensity = new Typecho_Widget_Helper_Form_Element_Text(
            'autumnDensity',
            null,
            '35',
            _t('落叶数量'),
            _t('建议范围 15-60')
        );
        $autumnDensity->input->setAttribute('type', 'number');
        $autumnDensity->input->setAttribute('min', '10');
        $autumnDensity->input->setAttribute('max', '100');
        $form->addInput($autumnDensity);

        // 冬 - 雪花
        $winter = new Typecho_Widget_Helper_Form_Element_Radio(
            'winter',
            ['1' => _t('开启'), '0' => _t('关闭')],
            '1',
            _t('❄️ 冬季 - 雪花纷飞'),
            _t('六角形雪花匀速垂直下落')
        );
        $form->addInput($winter);

        $winterDensity = new Typecho_Widget_Helper_Form_Element_Text(
            'winterDensity',
            null,
            '50',
            _t('雪花数量'),
            _t('建议范围 20-100')
        );
        $winterDensity->input->setAttribute('type', 'number');
        $winterDensity->input->setAttribute('min', '10');
        $winterDensity->input->setAttribute('max', '200');
        $form->addInput($winterDensity);

        // 提示信息
        $notice = new Typecho_Widget_Helper_Form_Element_Hidden('notice');
        $form->addInput($notice);
    }

    /**
     * 个人配置面板
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form)
    {
    }

    /**
     * 渲染特效
     */
    public static function render()
    {
        $options = Helper::options()->plugin('FourSeasons');
        
        // 检查是否有任何季节开启
        $activeSeasons = [];
        if (!empty($options->spring) && $options->spring === '1') {
            $activeSeasons[] = 'spring';
        }
        if (!empty($options->summer) && $options->summer === '1') {
            $activeSeasons[] = 'summer';
        }
        if (!empty($options->autumn) && $options->autumn === '1') {
            $activeSeasons[] = 'autumn';
        }
        if (!empty($options->winter) && $options->winter === '1') {
            $activeSeasons[] = 'winter';
        }

        if (empty($activeSeasons)) {
            return;
        }

        // 构建配置
        $config = [
            'seasons' => $activeSeasons,
            'simpleMode' => !empty($options->simpleMode) && $options->simpleMode === '1',
            'springDensity' => isset($options->springDensity) ? max(10, min(150, (int)$options->springDensity)) : 40,
            'summerDensity' => isset($options->summerDensity) ? max(20, min(200, (int)$options->summerDensity)) : 60,
            'autumnDensity' => isset($options->autumnDensity) ? max(10, min(100, (int)$options->autumnDensity)) : 35,
            'winterDensity' => isset($options->winterDensity) ? max(10, min(200, (int)$options->winterDensity)) : 50,
        ];

        $scriptUrl = Typecho_Common::url('FourSeasons/assets/seasons.js?v=' . self::VERSION, Helper::options()->pluginUrl);
        
        echo '<script>(function(w){w.FourSeasonsConfig=' . json_encode($config) . ';})(window);</script>';
        echo '<script src="' . htmlspecialchars($scriptUrl) . '" defer></script>';
    }
}
