<?php
/**
 * 四时絮语 — 四季粒子特效
 *
 * @package FourSeasons
 * @author Lin.
 * @version 1.2.0
 * @link https://linyu.live/
 */
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class FourSeasons_Plugin implements Typecho_Plugin_Interface
{
    private const VERSION = '1.2.0';

    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->footer = [__CLASS__, 'render'];
        return _t('四时絮语已激活，请在"插件 → FourSeasons"中配置。');
    }

    public static function deactivate()
    {
    }

    public static function config(Typecho_Widget_Helper_Form $form)
    {
        // ===== 简约模式 =====
        $simpleMode = new Typecho_Widget_Helper_Form_Element_Radio(
            'simpleMode',
            ['1' => _t('开启'), '0' => _t('关闭')],
            '0',
            _t('🎨 简约模式'),
            _t('用圆点代替复杂形状，性能更好')
        );
        $form->addInput($simpleMode);

        // ===== 春 - 樱花 =====
        $spring = new Typecho_Widget_Helper_Form_Element_Radio(
            'spring',
            ['1' => _t('开启'), '0' => _t('关闭')],
            '0',
            _t('🌸 春季 - 樱花飘落'),
            _t('')
        );
        $form->addInput($spring);

        $springDensity = new Typecho_Widget_Helper_Form_Element_Text(
            'springDensity', null, '50',
            _t('数量'), _t('10~150')
        );
        $springDensity->input->setAttribute('type', 'number');
        $springDensity->input->setAttribute('min', '10');
        $springDensity->input->setAttribute('max', '150');
        $form->addInput($springDensity);

        $springSpeed = new Typecho_Widget_Helper_Form_Element_Text(
            'springSpeed', null, '0.8',
            _t('速度'), _t('0.3~3')
        );
        $springSpeed->input->setAttribute('type', 'number');
        $springSpeed->input->setAttribute('min', '0.3');
        $springSpeed->input->setAttribute('max', '3');
        $springSpeed->input->setAttribute('step', '0.1');
        $form->addInput($springSpeed);

        $springSize = new Typecho_Widget_Helper_Form_Element_Text(
            'springSize', null, '0.9',
            _t('大小'), _t('0.5~2.5')
        );
        $springSize->input->setAttribute('type', 'number');
        $springSize->input->setAttribute('min', '0.5');
        $springSize->input->setAttribute('max', '2.5');
        $springSize->input->setAttribute('step', '0.1');
        $form->addInput($springSize);

        // ===== 夏 - 微光 =====
        $summer = new Typecho_Widget_Helper_Form_Element_Radio(
            'summer',
            ['1' => _t('开启'), '0' => _t('关闭')],
            '0',
            _t('🌿 夏季 - 柔和微光'),
            _t('')
        );
        $form->addInput($summer);

        $summerDensity = new Typecho_Widget_Helper_Form_Element_Text(
            'summerDensity', null, '35',
            _t('数量'), _t('10~100')
        );
        $summerDensity->input->setAttribute('type', 'number');
        $summerDensity->input->setAttribute('min', '10');
        $summerDensity->input->setAttribute('max', '100');
        $form->addInput($summerDensity);

        $summerSpeed = new Typecho_Widget_Helper_Form_Element_Text(
            'summerSpeed', null, '1',
            _t('速度'), _t('0.3~3')
        );
        $summerSpeed->input->setAttribute('type', 'number');
        $summerSpeed->input->setAttribute('min', '0.3');
        $summerSpeed->input->setAttribute('max', '3');
        $summerSpeed->input->setAttribute('step', '0.1');
        $form->addInput($summerSpeed);

        $summerSize = new Typecho_Widget_Helper_Form_Element_Text(
            'summerSize', null, '1',
            _t('大小'), _t('0.5~2.5')
        );
        $summerSize->input->setAttribute('type', 'number');
        $summerSize->input->setAttribute('min', '0.5');
        $summerSize->input->setAttribute('max', '2.5');
        $summerSize->input->setAttribute('step', '0.1');
        $form->addInput($summerSize);

        // ===== 秋 - 枫叶 =====
        $autumn = new Typecho_Widget_Helper_Form_Element_Radio(
            'autumn',
            ['1' => _t('开启'), '0' => _t('关闭')],
            '0',
            _t('🍁 秋季 - 枫叶飘零'),
            _t('')
        );
        $form->addInput($autumn);

        $autumnDensity = new Typecho_Widget_Helper_Form_Element_Text(
            'autumnDensity', null, '30',
            _t('数量'), _t('5~50')
        );
        $autumnDensity->input->setAttribute('type', 'number');
        $autumnDensity->input->setAttribute('min', '5');
        $autumnDensity->input->setAttribute('max', '50');
        $form->addInput($autumnDensity);

        $autumnSpeed = new Typecho_Widget_Helper_Form_Element_Text(
            'autumnSpeed', null, '0.8',
            _t('速度'), _t('0.3~3')
        );
        $autumnSpeed->input->setAttribute('type', 'number');
        $autumnSpeed->input->setAttribute('min', '0.3');
        $autumnSpeed->input->setAttribute('max', '3');
        $autumnSpeed->input->setAttribute('step', '0.1');
        $form->addInput($autumnSpeed);

        $autumnSize = new Typecho_Widget_Helper_Form_Element_Text(
            'autumnSize', null, '0.8',
            _t('大小'), _t('0.5~2.5')
        );
        $autumnSize->input->setAttribute('type', 'number');
        $autumnSize->input->setAttribute('min', '0.5');
        $autumnSize->input->setAttribute('max', '2.5');
        $autumnSize->input->setAttribute('step', '0.1');
        $form->addInput($autumnSize);

        // ===== 冬 - 雪花 =====
        $winter = new Typecho_Widget_Helper_Form_Element_Radio(
            'winter',
            ['1' => _t('开启'), '0' => _t('关闭')],
            '1',
            _t('❄️ 冬季 - 雪花纷飞'),
            _t('')
        );
        $form->addInput($winter);

        $winterDensity = new Typecho_Widget_Helper_Form_Element_Text(
            'winterDensity', null, '50',
            _t('数量'), _t('10~200')
        );
        $winterDensity->input->setAttribute('type', 'number');
        $winterDensity->input->setAttribute('min', '10');
        $winterDensity->input->setAttribute('max', '200');
        $form->addInput($winterDensity);

        $winterSpeed = new Typecho_Widget_Helper_Form_Element_Text(
            'winterSpeed', null, '0.6',
            _t('速度'), _t('0.3~3')
        );
        $winterSpeed->input->setAttribute('type', 'number');
        $winterSpeed->input->setAttribute('min', '0.3');
        $winterSpeed->input->setAttribute('max', '3');
        $winterSpeed->input->setAttribute('step', '0.1');
        $form->addInput($winterSpeed);

        $winterSize = new Typecho_Widget_Helper_Form_Element_Text(
            'winterSize', null, '0.6',
            _t('大小'), _t('0.5~2.5')
        );
        $winterSize->input->setAttribute('type', 'number');
        $winterSize->input->setAttribute('min', '0.5');
        $winterSize->input->setAttribute('max', '2.5');
        $winterSize->input->setAttribute('step', '0.1');
        $form->addInput($winterSize);

        $notice = new Typecho_Widget_Helper_Form_Element_Hidden('notice');
        $form->addInput($notice);
    }

    public static function personalConfig(Typecho_Widget_Helper_Form $form)
    {
    }

    public static function render()
    {
        $options = Helper::options()->plugin('FourSeasons');
        $activeSeasons = [];
        if (!empty($options->spring) && $options->spring === '1') $activeSeasons[] = 'spring';
        if (!empty($options->summer) && $options->summer === '1') $activeSeasons[] = 'summer';
        if (!empty($options->autumn) && $options->autumn === '1') $activeSeasons[] = 'autumn';
        if (!empty($options->winter) && $options->winter === '1') $activeSeasons[] = 'winter';
        if (empty($activeSeasons)) return;

        $config = [
            'seasons' => $activeSeasons,
            'simpleMode' => !empty($options->simpleMode) && $options->simpleMode === '1',
            'springDensity' => max(10, min(150, (int)($options->springDensity ?? 50))),
            'springSpeed'   => max(0.3, min(3, (float)($options->springSpeed ?? 0.8))),
            'springSize'    => max(0.5, min(2.5, (float)($options->springSize ?? 0.9))),
            'summerDensity' => max(10, min(100, (int)($options->summerDensity ?? 35))),
            'summerSpeed'   => max(0.3, min(3, (float)($options->summerSpeed ?? 1))),
            'summerSize'    => max(0.5, min(2.5, (float)($options->summerSize ?? 1))),
            'autumnDensity' => max(5, min(50, (int)($options->autumnDensity ?? 30))),
            'autumnSpeed'   => max(0.3, min(3, (float)($options->autumnSpeed ?? 0.8))),
            'autumnSize'    => max(0.5, min(2.5, (float)($options->autumnSize ?? 0.8))),
            'winterDensity' => max(10, min(200, (int)($options->winterDensity ?? 50))),
            'winterSpeed'   => max(0.3, min(3, (float)($options->winterSpeed ?? 0.6))),
            'winterSize'    => max(0.5, min(2.5, (float)($options->winterSize ?? 0.6))),
        ];

        $scriptUrl = Typecho_Common::url('FourSeasons/assets/seasons.js?v=' . self::VERSION, Helper::options()->pluginUrl);
        echo '<script>(function(w){w.FourSeasonsConfig=' . json_encode($config) . ';})(window);</script>';
        echo '<script src="' . htmlspecialchars($scriptUrl) . '" defer></script>';
    }
}
