(function (window) {
    'use strict';

    if (!window || window.__FourSeasonsInitialized) {
        return;
    }

    const config = window.FourSeasonsConfig || {};
    const seasons = config.seasons || ['winter'];
    const simpleMode = config.simpleMode || false;
    
    const densities = {
        spring: config.springDensity || 40,
        summer: config.summerDensity || 60,
        autumn: config.autumnDensity || 35,
        winter: config.winterDensity || 50
    };

    function injectBaseNodes() {
        let style = document.getElementById('four-seasons-style');
        if (!style) {
            style = document.createElement('style');
            style.id = 'four-seasons-style';
            style.textContent = '#four-seasons-canvas{position:fixed;top:0;left:0;width:100%;height:100%;z-index:99999;pointer-events:none;}';
            document.head.appendChild(style);
        }

        let canvas = document.getElementById('four-seasons-canvas');
        if (!canvas) {
            canvas = document.createElement('canvas');
            canvas.id = 'four-seasons-canvas';
            document.body.appendChild(canvas);
        }
        return canvas;
    }

    // 春季 - 单瓣樱花
    function SpringParticle(canvas) {
        this.canvas = canvas;
        this.reset();
        this.y = Math.random() * canvas.height;
    }

    SpringParticle.prototype.reset = function() {
        this.x = Math.random() * (this.canvas.width + 100) - 50;
        this.y = -20;
        this.size = Math.random() * 4 + 3;
        this.speedY = Math.random() * 0.8 + 0.4;
        this.speedX = Math.random() * 0.6 - 0.3;
        this.opacity = Math.random() * 0.3 + 0.4;
        this.rotation = Math.random() * Math.PI * 2;
        this.tilt = Math.random() * Math.PI;
        this.tiltSpeed = (Math.random() - 0.5) * 0.04;
        this.swayOffset = Math.random() * Math.PI * 2;
        
        var pinkColors = [
            [255, 192, 203], [255, 182, 193], [255, 200, 220], 
            [255, 174, 185], [255, 160, 180]
        ];
        var color = pinkColors[Math.floor(Math.random() * pinkColors.length)];
        this.color = 'rgba(' + color[0] + ',' + color[1] + ',' + color[2] + ',' + this.opacity + ')';
    };

    SpringParticle.prototype.update = function() {
        this.y += this.speedY;
        this.x += this.speedX + Math.sin(this.y * 0.01 + this.swayOffset) * 0.5;
        this.rotation += 0.008;
        this.tilt += this.tiltSpeed;
        
        if (this.y > this.canvas.height + 30) {
            this.reset();
        }
    };

    SpringParticle.prototype.draw = function(ctx) {
        if (simpleMode) {
            ctx.fillStyle = this.color;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size * 0.6, 0, Math.PI * 2);
            ctx.fill();
            return;
        }

        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);
        
        var tiltScale = Math.cos(this.tilt);
        ctx.scale(Math.abs(tiltScale) * 0.7 + 0.3, 1);
        
        ctx.fillStyle = this.color;
        ctx.strokeStyle = 'rgba(255, 150, 170, ' + this.opacity + ')';
        ctx.lineWidth = 0.4;
        
        ctx.beginPath();
        ctx.moveTo(0, -this.size);
        ctx.bezierCurveTo(
            this.size * 0.5, -this.size * 0.3,
            this.size * 0.6, this.size * 0.4,
            0, this.size * 0.5
        );
        ctx.bezierCurveTo(
            -this.size * 0.6, this.size * 0.4,
            -this.size * 0.5, -this.size * 0.3,
            0, -this.size
        );
        ctx.fill();
        ctx.stroke();
        
        ctx.beginPath();
        ctx.strokeStyle = 'rgba(255, 255, 255, ' + (this.opacity * 0.6) + ')';
        ctx.lineWidth = 0.5;
        ctx.moveTo(0, -this.size * 0.7);
        ctx.lineTo(0, this.size * 0.2);
        ctx.stroke();
        
        ctx.restore();
    };

    // 夏季 - 细雨
    function SummerParticle(canvas) {
        this.canvas = canvas;
        this.reset();
        this.y = Math.random() * canvas.height;
    }

    SummerParticle.prototype.reset = function() {
        this.x = Math.random() * (this.canvas.width + 60) - 30;
        this.y = -40;
        this.length = Math.random() * 15 + 8;
        this.speedY = Math.random() * 5 + 4;
        this.speedX = Math.random() * 0.4 + 0.2;
        this.opacity = Math.random() * 0.2 + 0.15;
        this.lineWidth = Math.random() * 0.8 + 0.3;
    };

    SummerParticle.prototype.update = function() {
        this.y += this.speedY;
        this.x += this.speedX;
        if (this.y > this.canvas.height) {
            this.reset();
        }
        if (this.x > this.canvas.width) {
            this.x = -20;
        }
    };

    SummerParticle.prototype.draw = function(ctx) {
        if (simpleMode) {
            ctx.strokeStyle = 'rgba(150, 180, 220, ' + this.opacity + ')';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(this.x, this.y);
            ctx.lineTo(this.x, this.y + 12);
            ctx.stroke();
            return;
        }
        
        ctx.strokeStyle = 'rgba(180, 200, 230, ' + this.opacity + ')';
        ctx.lineWidth = this.lineWidth;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(this.x, this.y);
        ctx.lineTo(this.x + this.speedX * 1.5, this.y + this.length);
        ctx.stroke();
    };

    // 秋季 - 落叶
    function AutumnParticle(canvas) {
        this.canvas = canvas;
        this.reset();
        this.y = Math.random() * canvas.height;
    }

    AutumnParticle.prototype.reset = function() {
        this.x = Math.random() * (this.canvas.width + 200) - 100;
        this.y = -30;
        this.size = Math.random() * 5 + 4;
        this.speedY = Math.random() * 1.2 + 0.6;
        this.speedX = (Math.random() - 0.5) * 1.5;
        this.rotation = Math.random() * Math.PI * 2;
        this.rotationSpeed = (Math.random() - 0.5) * 0.05;
        this.opacity = Math.random() * 0.2 + 0.65;
        this.swayFreq = Math.random() * 0.008 + 0.003;
        this.swayAmp = Math.random() * 1.5 + 0.5;
        this.swayOffset = Math.random() * Math.PI * 2;
        
        var colors = [
            'rgba(218, 165, 32, ' + this.opacity + ')',
            'rgba(205, 92, 92, ' + this.opacity + ')',
            'rgba(178, 34, 34, ' + this.opacity + ')',
            'rgba(210, 105, 30, ' + this.opacity + ')',
            'rgba(139, 69, 19, ' + this.opacity + ')',
            'rgba(244, 164, 96, ' + this.opacity + ')'
        ];
        this.color = colors[Math.floor(Math.random() * colors.length)];
    };

    AutumnParticle.prototype.update = function() {
        this.y += this.speedY;
        
        if (simpleMode) {
            this.x += Math.sin(this.y * 0.015 + this.swayOffset) * 0.4;
        } else {
            this.x += this.speedX + Math.sin(this.y * this.swayFreq + this.swayOffset) * this.swayAmp;
        }
        
        this.rotation += this.rotationSpeed;
        
        if (this.y > this.canvas.height + 30) {
            this.reset();
        }
        if (this.x > this.canvas.width + 50) {
            this.x = -50;
        } else if (this.x < -50) {
            this.x = this.canvas.width + 50;
        }
    };

    AutumnParticle.prototype.draw = function(ctx) {
        if (simpleMode) {
            ctx.fillStyle = this.color;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size * 0.6, 0, Math.PI * 2);
            ctx.fill();
            return;
        }

        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);
        ctx.fillStyle = this.color;
        ctx.strokeStyle = 'rgba(100, 50, 10, ' + (this.opacity * 0.3) + ')';
        ctx.lineWidth = 0.3;
        
        ctx.beginPath();
        ctx.moveTo(0, this.size);
        ctx.bezierCurveTo(
            -this.size * 0.3, this.size * 0.5,
            -this.size * 0.8, 0,
            -this.size * 0.4, -this.size * 0.3
        );
        ctx.bezierCurveTo(
            -this.size * 0.2, -this.size * 0.8,
            0, -this.size * 0.9,
            0, -this.size * 0.9
        );
        ctx.bezierCurveTo(
            0, -this.size * 0.9,
            this.size * 0.2, -this.size * 0.8,
            this.size * 0.4, -this.size * 0.3
        );
        ctx.bezierCurveTo(
            this.size * 0.8, 0,
            this.size * 0.3, this.size * 0.5,
            0, this.size
        );
        ctx.fill();
        ctx.stroke();
        
        ctx.beginPath();
        ctx.strokeStyle = 'rgba(80, 40, 10, ' + (this.opacity * 0.4) + ')';
        ctx.lineWidth = 0.6;
        ctx.moveTo(0, this.size * 0.8);
        ctx.lineTo(0, -this.size * 0.6);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.lineWidth = 0.3;
        ctx.moveTo(0, -this.size * 0.2);
        ctx.lineTo(-this.size * 0.3, -this.size * 0.1);
        ctx.moveTo(0, 0);
        ctx.lineTo(-this.size * 0.25, 0.1);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.moveTo(0, -this.size * 0.2);
        ctx.lineTo(this.size * 0.3, -this.size * 0.1);
        ctx.moveTo(0, 0);
        ctx.lineTo(this.size * 0.25, 0.1);
        ctx.stroke();
        
        ctx.restore();
    };

    // 冬季 - 雪花（真实圆润六角，小巧版）
    function WinterParticle(canvas) {
        this.canvas = canvas;
        this.reset();
        this.y = Math.random() * canvas.height;
    }

    WinterParticle.prototype.reset = function() {
        this.x = Math.random() * (this.canvas.width + 100) - 50;
        this.y = -15;
        this.size = Math.random() * 2 + 2; // 小巧：2-4px
        this.speedY = Math.random() * 0.8 + 0.5;
        this.opacity = Math.random() * 0.25 + 0.45;
        this.rotation = Math.random() * Math.PI * 2;
        this.rotationSpeed = (Math.random() - 0.5) * 0.015;
        this.swayOffset = Math.random() * Math.PI * 2;
    };

    WinterParticle.prototype.update = function() {
        this.y += this.speedY;
        this.x += Math.sin(this.y * 0.015 + this.swayOffset) * 0.4;
        this.rotation += this.rotationSpeed;
        if (this.y > this.canvas.height + 20) {
            this.reset();
        }
    };

    WinterParticle.prototype.draw = function(ctx) {
        if (simpleMode) {
            ctx.fillStyle = 'rgba(255, 255, 255, ' + this.opacity + ')';
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size * 1.1, 0, Math.PI * 2);
            ctx.fill();
            return;
        }

        // 正常模式：真实圆润六角雪花（中心圆盘 + 六个圆角突起）
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);
        
        ctx.fillStyle = 'rgba(255, 255, 255, ' + this.opacity + ')';
        
        // 中心圆盘（小巧）
        ctx.beginPath();
        ctx.arc(0, 0, this.size * 0.5, 0, Math.PI * 2);
        ctx.fill();
        
        // 六个圆润小角（椭圆突起）
        for (var i = 0; i < 6; i++) {
            ctx.save();
            ctx.rotate((Math.PI / 3) * i);
            
            // 圆润的小突起
            ctx.beginPath();
            ctx.ellipse(0, -this.size * 0.9, this.size * 0.35, this.size * 0.6, 0, 0, Math.PI * 2);
            ctx.fill();
            
            ctx.restore();
        }
        
        ctx.restore();
    };

    function boot() {
        window.__FourSeasonsInitialized = true;
        var canvas = injectBaseNodes();
        var ctx = canvas.getContext('2d');
        var particles = [];
        var animationId;

        window.requestAnimationFrame = window.requestAnimationFrame || 
            window.mozRequestAnimationFrame || 
            window.webkitRequestAnimationFrame || 
            window.msRequestAnimationFrame || 
            function (callback) {
                return window.setTimeout(callback, 1000 / 60);
            };

        function resizeCanvas() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }

        function initParticles() {
            particles = [];
            for (var s = 0; s < seasons.length; s++) {
                var season = seasons[s];
                var count = densities[season] || 50;
                var ParticleClass;
                switch(season) {
                    case 'spring': ParticleClass = SpringParticle; break;
                    case 'summer': ParticleClass = SummerParticle; break;
                    case 'autumn': ParticleClass = AutumnParticle; break;
                    case 'winter': ParticleClass = WinterParticle; break;
                    default: ParticleClass = WinterParticle;
                }
                for (var i = 0; i < count; i++) {
                    particles.push(new ParticleClass(canvas));
                }
            }
        }

        function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            for (var i = 0; i < particles.length; i++) {
                particles[i].update();
                particles[i].draw(ctx);
            }
            animationId = window.requestAnimationFrame(animate);
        }

        function init() {
            resizeCanvas();
            initParticles();
            animate();
        }

        window.addEventListener('resize', function() {
            resizeCanvas();
            initParticles();
        });

        console.log('%c FourSeasons Plugin %c 四季特效已加载' + (simpleMode ? ' [简约模式]' : ''), 
            'color:#fff;background:linear-gradient(90deg, #ffb7b2, #ffdac1, #e2f0cb, #b5ead7);padding:5px;border-radius:3px 0 0 3px;', 
            'background:#2d3436;color:#fff;padding:5px;border-radius:0 3px 3px 0;');
        
        init();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})(window);
