(function (window) {
    'use strict';

    if (!window || window.__FourSeasonsInitialized) return;

    var STORAGE_KEY = '__FourSeasonsState_v5';
    var config = window.FourSeasonsConfig || {};
    var seasons = config.seasons || ['winter'];
    var simpleMode = config.simpleMode || false;

    var densities = {
        spring: config.springDensity || 50,
        summer: config.summerDensity || 35,
        autumn: config.autumnDensity || 30,
        winter: config.winterDensity || 50
    };
    var speedMul = {
        spring: config.springSpeed || 0.8,
        summer: config.summerSpeed || 1,
        autumn: config.autumnSpeed || 0.8,
        winter: config.winterSpeed || 0.6
    };
    var sizeMul = {
        spring: config.springSize || 0.9,
        summer: config.summerSize || 1,
        autumn: config.autumnSize || 0.8,
        winter: config.winterSize || 0.6
    };

    /* ============================================================
       状态保持
       ============================================================ */
    var savedState = null;
    try {
        var raw = sessionStorage.getItem(STORAGE_KEY);
        if (raw) { savedState = JSON.parse(raw); sessionStorage.removeItem(STORAGE_KEY); }
    } catch (e) {}

    window.addEventListener('beforeunload', function () {
        try {
            if (!window.__fsParticles || !window.__fsParticles.length) return;
            var state = [];
            for (var i = 0; i < window.__fsParticles.length; i++) {
                var p = window.__fsParticles[i];
                state.push({ x: p.x, y: p.y, r: p.rotation || 0, s: p._season || '' });
            }
            sessionStorage.setItem(STORAGE_KEY, JSON.stringify({ w: window.innerWidth, h: window.innerHeight, t: Date.now(), particles: state }));
        } catch (e) {}
    });

    function injectNodes() {
        var style = document.getElementById('four-seasons-style');
        if (!style) {
            style = document.createElement('style');
            style.id = 'four-seasons-style';
            style.textContent = '#four-seasons-canvas{position:fixed;top:0;left:0;width:100%;height:100%;z-index:99999;pointer-events:none;}';
            document.head.appendChild(style);
        }
        var canvas = document.getElementById('four-seasons-canvas');
        if (!canvas) {
            canvas = document.createElement('canvas');
            canvas.id = 'four-seasons-canvas';
            document.body.appendChild(canvas);
        }
        return canvas;
    }

    function rand(a, b) { return Math.random() * (b - a) + a; }
    function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

    var mouseX = 0, mouseY = 0;

    /* ============================================================
       春天 — 樱花
       ============================================================ */
    function SpringParticle(canvas, restore) {
        this.canvas = canvas;
        this._season = 'spring';
        this.reset(true, restore);
    }

    SpringParticle.prototype.reset = function (initial, restore) {
        var sm = sizeMul.spring;
        if (restore && restore.x != null) {
            this.x = restore.x; this.y = restore.y;
            this.rotation = restore.r || 0;
        } else if (initial) {
            this.x = rand(-50, this.canvas.width + 50);
            this.y = rand(-30, this.canvas.height + 30);
            this.rotation = rand(0, Math.PI * 2);
        } else {
            this.x = rand(-50, this.canvas.width + 50);
            this.y = -20;
            this.rotation = rand(0, Math.PI * 2);
        }
        this.size = rand(4, 8) * sm;
        this.speedY = rand(0.4, 0.9) * speedMul.spring;
        this.speedX = rand(-0.3, 0.3);
        this.opacity = rand(0.5, 0.78);
        this.swayOffset = rand(0, Math.PI * 2);
        this.tilt = rand(0, Math.PI);
        this.tiltSpeed = rand(-0.04, 0.04);
        this.rotX = rand(0, Math.PI * 2);
        this.rotY = rand(0, Math.PI * 2);
        this.rotXSpeed = rand(-0.04, 0.04);
        this.rotYSpeed = rand(-0.03, 0.03);
        var colors = [[255,183,197],[255,192,203],[255,200,220],[255,160,180],[255,174,185]];
        var c = pick(colors);
        this.r = c[0]; this.g = c[1]; this.b = c[2];
    };

    SpringParticle.prototype.update = function () {
        this.y += this.speedY;
        this.x += this.speedX + Math.sin(this.y * 0.01 + this.swayOffset) * 0.5;
        this.rotation += 0.008;
        this.tilt += this.tiltSpeed;
        this.rotX += this.rotXSpeed;
        this.rotY += this.rotYSpeed;
        this.x += mouseX * 2;
        this.y += mouseY * 0.6;
        if (this.y > this.canvas.height + 30) {
            this.x = rand(-50, this.canvas.width + 50);
            this.y = -20;
        }
    };

    SpringParticle.prototype.draw = function (ctx) {
        if (simpleMode) {
            // 简约模式：简化花瓣（椭圆+小尖）
            ctx.save();
            ctx.translate(this.x, this.y);
            ctx.rotate(this.rotation);
            ctx.fillStyle = 'rgba(' + this.r + ',' + this.g + ',' + this.b + ',' + this.opacity + ')';
            ctx.beginPath();
            ctx.moveTo(0, -this.size);
            ctx.bezierCurveTo(this.size * 0.5, -this.size * 0.2, this.size * 0.5, this.size * 0.3, 0, this.size * 0.5);
            ctx.bezierCurveTo(-this.size * 0.5, this.size * 0.3, -this.size * 0.5, -this.size * 0.2, 0, -this.size);
            ctx.fill();
            ctx.restore();
            return;
        }
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);
        var sx = Math.abs(Math.cos(this.rotX)) * 0.5 + 0.5;
        var sy = Math.abs(Math.cos(this.rotY)) * 0.5 + 0.5;
        ctx.scale(sx, sy);
        ctx.fillStyle = 'rgba(' + this.r + ',' + this.g + ',' + this.b + ',' + this.opacity + ')';
        ctx.beginPath();
        ctx.moveTo(0, -this.size);
        ctx.bezierCurveTo(this.size * 0.6, -this.size * 0.3, this.size * 0.7, this.size * 0.4, 0, this.size * 0.6);
        ctx.bezierCurveTo(-this.size * 0.7, this.size * 0.4, -this.size * 0.6, -this.size * 0.3, 0, -this.size);
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,' + (this.opacity * 0.5) + ')';
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        ctx.moveTo(0, -this.size * 0.7);
        ctx.lineTo(0, this.size * 0.3);
        ctx.stroke();
        ctx.shadowColor = 'rgba(' + this.r + ',' + this.g + ',' + this.b + ',0.4)';
        ctx.shadowBlur = 6;
        ctx.restore();
    };

    /* ============================================================
       夏天 — 柔和微光（淡黄绿光点，不刺眼，缓缓向上）
       ============================================================ */
    function SummerParticle(canvas, restore) {
        this.canvas = canvas;
        this._season = 'summer';
        this.reset(true, restore);
    }

    SummerParticle.prototype.reset = function (initial, restore) {
        var sm = sizeMul.summer;
        var w = this.canvas.width, h = this.canvas.height;
        if (restore && restore.x != null) {
            this.x = restore.x; this.y = restore.y;
        } else if (initial) {
            this.x = rand(-50, w + 50);
            this.y = rand(-50, h + 50);
        } else {
            this.x = rand(-50, w + 50);
            this.y = h + rand(30, 80);
        }
        this.size = rand(4, 8) * sm;
        // 总体向上，但非常缓慢
        this.speedY = rand(-0.35, -0.15) * speedMul.summer;
        this.swayAmp = rand(0.6, 1.4);
        this.swayFreq = rand(0.004, 0.01);
        this.swayOffset = rand(0, Math.PI * 2);
        this.floatPhase = rand(0, Math.PI * 2);
        this.floatSpeed = rand(0.0005, 0.0012);
        // 柔和的低透明度，不刺眼
        this.opacity = rand(0.2, 0.38);
        // 淡黄绿色，低饱和度，柔和
        var colors = [
            [210, 230, 170], [200, 225, 160], [220, 235, 180],
            [195, 220, 155], [205, 228, 165]
        ];
        var c = pick(colors);
        this.r = c[0]; this.g = c[1]; this.b = c[2];
    };

    SummerParticle.prototype.update = function () {
        var t = Date.now();
        var swayX = Math.sin(this.y * this.swayFreq + this.swayOffset) * this.swayAmp;
        var floatY = Math.sin(t * this.floatSpeed + this.floatPhase) * 0.2;
        this.x += swayX * 0.12 + mouseX * 1.2;
        this.y += this.speedY + floatY + mouseY * 0.4;
        // 飘出顶部 → 从底部重新进入
        if (this.y < -40) {
            this.y = this.canvas.height + rand(30, 80);
        }
        // 左右环绕
        if (this.x > this.canvas.width + 40) this.x = -30;
        if (this.x < -40) this.x = this.canvas.width + 30;
        if (this.y > this.canvas.height + 100) this.y = -30;
    };

    SummerParticle.prototype.draw = function (ctx) {
        var s = this.size, a = this.opacity;
        ctx.save();
        ctx.translate(this.x, this.y);

        if (simpleMode) {
            ctx.fillStyle = 'rgba(' + this.r + ',' + this.g + ',' + this.b + ',' + a + ')';
            ctx.beginPath();
            ctx.arc(0, 0, s * 0.5, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
            return;
        }

        // 极简柔光 — 只有一个淡淡的圆点
        ctx.fillStyle = 'rgba(' + this.r + ',' + this.g + ',' + this.b + ',' + a + ')';
        ctx.beginPath();
        ctx.arc(0, 0, s * 0.5, 0, Math.PI * 2);
        ctx.fill();

        // 极小的高光中心（让光点有层次感，但不刺眼）
        ctx.fillStyle = 'rgba(255,255,255,' + (a * 0.4) + ')';
        ctx.beginPath();
        ctx.arc(s * 0.05, -s * 0.05, s * 0.15, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
    };

    /* ============================================================
       秋天 — 枫叶（飘旋下落，不扎堆）
       ============================================================ */
    function AutumnParticle(canvas, restore) {
        this.canvas = canvas;
        this._season = 'autumn';
        this.reset(true, restore);
    }

    AutumnParticle.prototype.reset = function (initial, restore) {
        var sm = sizeMul.autumn;
        var w = this.canvas.width;
        if (restore && restore.x != null) {
            this.x = restore.x; this.y = restore.y;
            this.rotation = restore.r || 0;
        } else if (initial) {
            this.x = rand(-50, w + 50);
            this.y = rand(-30, this.canvas.height + 30);
            this.rotation = rand(0, Math.PI * 2);
        } else {
            // 重置时 x 均匀散布，不往一边扎堆
            this.x = rand(-50, w + 50);
            this.y = -30;
            this.rotation = rand(0, Math.PI * 2);
        }
        this.size = rand(6, 10) * sm;
        this.speedY = rand(0.35, 0.6) * speedMul.autumn;
        // 飘旋：每个叶子有自己独立的摆动频率和幅度
        this.swayAmp = rand(0.6, 1.5);
        this.swayFreq = rand(0.004, 0.009);
        this.swayOffset = rand(0, Math.PI * 2);
        this.rotationSpeed = rand(-0.018, 0.018);
        this.opacity = rand(0.75, 0.92);
        var colors = [[205,92,52],[218,145,32],[178,60,30],[210,120,40],[180,75,35]];
        var c = pick(colors);
        this.r = c[0]; this.g = c[1]; this.b = c[2];
    };

    AutumnParticle.prototype.update = function () {
        this.y += this.speedY;
        // 飘来飘去的感觉：sin 摆动，幅度适中
        this.x += Math.sin(this.y * this.swayFreq + this.swayOffset) * this.swayAmp;
        this.rotation += this.rotationSpeed;
        this.x += mouseX * 1.5;
        this.y += mouseY * 0.4;
        if (this.y > this.canvas.height + 40) {
            this.x = rand(-50, this.canvas.width + 50);
            this.y = -30;
        }
    };

    AutumnParticle.prototype.draw = function (ctx) {
        if (simpleMode) {
            // 简约模式：简化枫叶轮廓（五瓣+叶柄）
            ctx.save();
            ctx.translate(this.x, this.y);
            ctx.rotate(this.rotation);
            var s = this.size;
            ctx.fillStyle = 'rgba(' + this.r + ',' + this.g + ',' + this.b + ',' + this.opacity + ')';
            ctx.beginPath();
            ctx.moveTo(0, s * 0.9);
            ctx.bezierCurveTo(s * 0.25, s * 0.55, s * 0.6, s * 0.35, s * 0.5, s * 0.05);
            ctx.bezierCurveTo(s * 0.65, -s * 0.25, s * 0.35, -s * 0.55, s * 0.15, -s * 0.5);
            ctx.bezierCurveTo(s * 0.1, -s * 0.85, 0, -s * 0.95, 0, -s * 0.85);
            ctx.bezierCurveTo(0, -s * 0.95, -s * 0.1, -s * 0.85, -s * 0.15, -s * 0.5);
            ctx.bezierCurveTo(-s * 0.35, -s * 0.55, -s * 0.65, -s * 0.25, -s * 0.5, s * 0.05);
            ctx.bezierCurveTo(-s * 0.6, s * 0.35, -s * 0.25, s * 0.55, 0, s * 0.9);
            ctx.closePath();
            ctx.fill();
            ctx.restore();
            return;
        }
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);
        var s = this.size;
        ctx.fillStyle = 'rgba(' + this.r + ',' + this.g + ',' + this.b + ',' + this.opacity + ')';
        ctx.beginPath();
        ctx.moveTo(0, s);
        ctx.bezierCurveTo(s * 0.3, s * 0.5, s * 0.7, s * 0.3, s * 0.5, s * 0.05);
        ctx.bezierCurveTo(s * 0.6, 0, s * 0.4, -s * 0.15, s * 0.25, -s * 0.05);
        ctx.bezierCurveTo(s * 0.6, -s * 0.15, s * 0.75, -s * 0.35, s * 0.55, -s * 0.45);
        ctx.bezierCurveTo(s * 0.6, -s * 0.55, s * 0.35, -s * 0.6, s * 0.2, -s * 0.5);
        ctx.bezierCurveTo(s * 0.15, -s * 0.85, 0, -s, 0, -s * 0.9);
        ctx.bezierCurveTo(0, -s, -s * 0.15, -s * 0.85, -s * 0.2, -s * 0.5);
        ctx.bezierCurveTo(-s * 0.35, -s * 0.6, -s * 0.6, -s * 0.55, -s * 0.55, -s * 0.45);
        ctx.bezierCurveTo(-s * 0.75, -s * 0.35, -s * 0.6, -s * 0.15, -s * 0.25, -s * 0.05);
        ctx.bezierCurveTo(-s * 0.4, -s * 0.15, -s * 0.6, 0, -s * 0.5, s * 0.05);
        ctx.bezierCurveTo(-s * 0.7, s * 0.3, -s * 0.3, s * 0.5, 0, s);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(80,35,10,' + (this.opacity * 0.4) + ')';
        ctx.lineWidth = 0.5;
        ctx.beginPath();
        ctx.moveTo(0, s * 0.8);
        ctx.lineTo(0, -s * 0.65);
        ctx.stroke();
        ctx.lineWidth = 0.3;
        for (var i = 0; i < 3; i++) {
            var t = (i + 1) / 4;
            var vy = s * 0.6 - t * s * 1.1;
            var vl = s * 0.22 * (1 - t * 0.35);
            ctx.beginPath(); ctx.moveTo(0, vy); ctx.lineTo(vl, vy - s * 0.12); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(0, vy); ctx.lineTo(-vl, vy - s * 0.12); ctx.stroke();
        }
        ctx.restore();
    };

    /* ============================================================
       冬天 — 真实冰晶雪花（六角 dendrite + 自然飘落）
       ============================================================ */
    function SnowParticle(canvas, layer, restore) {
        this.canvas = canvas;
        this._season = 'winter';
        this.layer = layer || 1;
        this.reset(true, restore);
    }

    SnowParticle.prototype.reset = function (initial, restore) {
        var sm = sizeMul.winter;
        var w = this.canvas.width, h = this.canvas.height;
        switch (this.layer) {
            case 0: // 前景
                this.size = rand(5, 9) * sm;
                this.speedY = rand(0.6, 1.1) * speedMul.winter;
                this.opacity = rand(0.75, 0.92);
                this.blur = 0;
                break;
            case 1: // 中景
                this.size = rand(2.5, 5) * sm;
                this.speedY = rand(0.35, 0.65) * speedMul.winter;
                this.opacity = rand(0.5, 0.7);
                this.blur = 0;
                break;
            case 2: // 背景
                this.size = rand(1.2, 2.8) * sm;
                this.speedY = rand(0.12, 0.3) * speedMul.winter;
                this.opacity = rand(0.18, 0.38);
                this.blur = 1.5;
                break;
        }
        if (restore && restore.x != null) {
            this.x = restore.x; this.y = restore.y;
            this.rotation = restore.r || 0;
        } else if (initial) {
            this.x = rand(-50, w + 50);
            this.y = rand(-20, h + 20);
            this.rotation = rand(0, Math.PI * 2);
        } else {
            this.x = rand(-50, w + 50);
            this.y = -15;
            this.rotation = rand(0, Math.PI * 2);
        }
        // 真实雪花飘落参数
        this.rotSpeed = rand(-0.008, 0.008);
        this.swayAmp = rand(0.3, 0.8);
        this.swayFreq = rand(0.003, 0.007);
        this.swayOffset = rand(0, Math.PI * 2);
        this.fallPhase = rand(0, Math.PI * 2);
    };

    SnowParticle.prototype.update = function () {
        this.y += this.speedY;
        // 真实雪花：轻微左右摇摆 + 缓慢自转
        this.x += Math.sin(this.y * this.swayFreq + this.swayOffset) * this.swayAmp * 0.3;
        this.rotation += this.rotSpeed;
        var mf = this.layer === 2 ? 0.2 : this.layer === 1 ? 0.5 : 1.0;
        this.x += mouseX * 1.2 * mf;
        this.y += mouseY * 0.35 * mf;
        if (this.y > this.canvas.height + 20) {
            this.x = rand(-50, this.canvas.width + 50);
            this.y = -15;
        }
    };

    SnowParticle.prototype.draw = function (ctx) {
        var s = this.size, a = this.opacity;
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);

        if (simpleMode) {
            // 简约模式：圆点粒子，但保留三层视差差异
            if (this.blur > 0) {
                ctx.shadowColor = 'rgba(240,248,255,' + (a * 0.5) + ')';
                ctx.shadowBlur = this.blur * 3;
            }
            ctx.fillStyle = 'rgba(240,248,255,' + a + ')';
            ctx.beginPath();
            ctx.arc(0, 0, s, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
            return;
        }

        if (this.blur > 0) {
            ctx.shadowColor = 'rgba(240,248,255,' + (a * 0.5) + ')';
            ctx.shadowBlur = this.blur * 3;
        }

        // 真实冰晶雪花：六角 dendrite 结构
        ctx.strokeStyle = 'rgba(230,245,255,' + a + ')';
        ctx.fillStyle = 'rgba(240,248,255,' + (a * 0.7) + ')';
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        // 6个主臂 + 不规则分叉
        for (var i = 0; i < 6; i++) {
            var ang = (Math.PI / 3) * i;
            ctx.save();
            ctx.rotate(ang);

            var armW = Math.max(0.5, s * 0.08);
            ctx.lineWidth = armW;

            // 主臂（带轻微弯曲，不是直棍）
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.quadraticCurveTo(rand(-s*0.05, s*0.05), -s*0.5, 0, -s);
            ctx.stroke();

            if (this.layer <= 1) {
                // 主臂上的分叉（左右交替，不规则）
                var forkPositions = [0.35, 0.62, 0.85];
                var forkAngles = [0.55, 0.45, 0.35]; // 分叉角度递减
                var forkLens = [0.28, 0.22, 0.15];

                for (var f = 0; f < (this.layer === 0 ? 3 : 2); f++) {
                    var fp = forkPositions[f];
                    var fa = forkAngles[f] + rand(-0.05, 0.05); // 轻微随机
                    var fl = forkLens[f] * s;
                    var fy = -fp * s;

                    ctx.lineWidth = armW * (0.6 - f * 0.12);

                    // 左分叉
                    ctx.beginPath();
                    ctx.moveTo(0, fy);
                    ctx.lineTo(Math.sin(-fa) * fl, fy - Math.cos(-fa) * fl);
                    ctx.stroke();

                    // 右分叉
                    ctx.beginPath();
                    ctx.moveTo(0, fy);
                    ctx.lineTo(Math.sin(fa) * fl, fy - Math.cos(fa) * fl);
                    ctx.stroke();

                    // 前景：分叉末端小圆点
                    if (this.layer === 0 && f < 2) {
                        ctx.fillStyle = 'rgba(255,255,255,' + (a * 0.6) + ')';
                        ctx.beginPath();
                        ctx.arc(Math.sin(-fa) * fl * 0.9, fy - Math.cos(-fa) * fl * 0.9, s * 0.04, 0, Math.PI * 2);
                        ctx.fill();
                        ctx.beginPath();
                        ctx.arc(Math.sin(fa) * fl * 0.9, fy - Math.cos(fa) * fl * 0.9, s * 0.04, 0, Math.PI * 2);
                        ctx.fill();
                    }
                }

                // 主臂末端稍宽的"叶尖"
                ctx.lineWidth = armW * 0.8;
                ctx.beginPath();
                ctx.moveTo(0, -s * 0.92);
                ctx.lineTo(-s * 0.08, -s * 1.02);
                ctx.lineTo(0, -s * 1.08);
                ctx.lineTo(s * 0.08, -s * 1.02);
                ctx.closePath();
                ctx.fillStyle = 'rgba(240,248,255,' + (a * 0.5) + ')';
                ctx.fill();
            }

            // 臂尖端小点
            ctx.fillStyle = 'rgba(255,255,255,' + (a * 0.8) + ')';
            ctx.beginPath();
            ctx.arc(0, -s, s * 0.06, 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();
        }

        // 中心六角核（冰晶中心）
        ctx.fillStyle = 'rgba(255,255,255,' + (a * 0.85) + ')';
        ctx.beginPath();
        for (var i = 0; i < 6; i++) {
            var a6 = (Math.PI / 3) * i - Math.PI / 2;
            var r6 = s * 0.1;
            var x6 = Math.cos(a6) * r6;
            var y6 = Math.sin(a6) * r6;
            if (i === 0) ctx.moveTo(x6, y6);
            else ctx.lineTo(x6, y6);
        }
        ctx.closePath();
        ctx.fill();

        // 中心亮点
        ctx.fillStyle = 'rgba(255,255,255,' + (a * 0.5) + ')';
        ctx.beginPath();
        ctx.arc(0, 0, s * 0.06, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
    };

    /* ============================================================
       主程序
       ============================================================ */
    var particles = [];

    function boot() {
        window.__FourSeasonsInitialized = true;
        var canvas = injectNodes();
        var ctx = canvas.getContext('2d');
        var animationId = null;
        var isVisible = true;
        window.__fsParticles = particles;

        window.requestAnimationFrame = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || function (cb) { return setTimeout(cb, 1000 / 60); };
        window.cancelAnimationFrame = window.cancelAnimationFrame || window.webkitCancelAnimationFrame || window.mozCancelAnimationFrame || function (id) { clearTimeout(id); };

        function resize() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }

        function initParticles() {
            particles = [];
            var saved = (savedState && savedState.particles) ? savedState.particles : [];
            var idx = 0;
            for (var s = 0; s < seasons.length; s++) {
                var season = seasons[s];
                var count = densities[season] || 50;
                if (season === 'spring') {
                    for (var i = 0; i < count; i++) { particles.push(new SpringParticle(canvas, idx < saved.length ? saved[idx] : null)); idx++; }
                } else if (season === 'summer') {
                    for (var i = 0; i < count; i++) { particles.push(new SummerParticle(canvas, idx < saved.length ? saved[idx] : null)); idx++; }
                } else if (season === 'autumn') {
                    for (var i = 0; i < count; i++) { particles.push(new AutumnParticle(canvas, idx < saved.length ? saved[idx] : null)); idx++; }
                } else if (season === 'winter') {
                    var fg = Math.floor(count * 0.3);
                    var mg = Math.floor(count * 0.4);
                    var bg = count - fg - mg;
                    for (var i = 0; i < fg; i++) { particles.push(new SnowParticle(canvas, 0, idx < saved.length ? saved[idx] : null)); idx++; }
                    for (var i = 0; i < mg; i++) { particles.push(new SnowParticle(canvas, 1, idx < saved.length ? saved[idx] : null)); idx++; }
                    for (var i = 0; i < bg; i++) { particles.push(new SnowParticle(canvas, 2, idx < saved.length ? saved[idx] : null)); idx++; }
                }
            }
            window.__fsParticles = particles;
        }

        function animate() {
            if (!isVisible) { animationId = null; return; }
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            for (var i = 0; i < particles.length; i++) { particles[i].update(); particles[i].draw(ctx); }
            animationId = window.requestAnimationFrame(animate);
        }

        function start() { if (!animationId) { isVisible = true; animationId = window.requestAnimationFrame(animate); } }
        function stop() { if (animationId) { window.cancelAnimationFrame(animationId); animationId = null; } }

        document.addEventListener('mousemove', function (e) {
            mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
            mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
        });

        var rTimer = null;
        window.addEventListener('resize', function () {
            if (rTimer) clearTimeout(rTimer);
            rTimer = setTimeout(function () {
                var oldW = canvas.width, oldH = canvas.height;
                resize();
                if (oldW && oldH) {
                    for (var i = 0; i < particles.length; i++) {
                        var p = particles[i];
                        p.x = p.x * (canvas.width / oldW);
                        p.y = p.y * (canvas.height / oldH);
                    }
                }
            }, 250);
        });

        document.addEventListener('visibilitychange', function () {
            if (document.hidden) { isVisible = false; stop(); } else { start(); }
        });

        resize();
        initParticles();
        start();

        console.log('%c FourSeasons %c v1.3 Canvas · 已加载',
            'color:#fff;background:linear-gradient(90deg,#ffb7b2,#ffdac1,#e2f0cb,#b5ead7);padding:4px 8px;border-radius:3px 0 0 3px;font-weight:bold;',
            'background:#2d3436;color:#fff;padding:4px 8px;border-radius:0 3px 3px 0;');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})(window);
